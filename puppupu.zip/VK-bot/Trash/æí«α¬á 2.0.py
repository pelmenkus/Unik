from vk_api.longpoll import VkLongPoll, VkEventType
import vk_api
from datetime import datetime
import random
import time
import pyowm #pip pyowm install -- для OWM погоды; устанавливать версию 2.10.0 !
import requests
from bs4 import BeautifulSoup #pip install beautifulsoup4 -- для html погоды

headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36'}

token = "b99dd675ad7d4febd15c45e6d6ea0edcdbc100b19a4c4281d819ad9025e3bf3912c8927caaa83bc2ff9e5"
vk_session = vk_api.VkApi(token=token)
session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)

def write_msg(user_id, message):
    vk_session.method('messages.send', {'user_id': user_id, 'message': message, 'random_id': random.getrandbits(64)})

# Инфа
def info(user_id, message):  # шобы работало нужно import bs4 и requests
    try:
        message = message[5:len(message)]
        id = message[message.rfind('/') + 1:len(message)]  # оставляю только id пользователя или его "ник"
        response = vk_session.method('users.get', {'user_ids': id, 'fields': 'sex, counters'})  # получаю инфу о человеке
        id = str(response[0]['id'])  # теперь это именно id
        # print(id)

        first_name = response[0]['first_name']  # выкапываю имя
        last_name = response[0]['last_name']  # вытаскиваю фамилию

        sex_int = response[0]['sex']  # выкорчовываю пол (0, 1, 2)
        sex = {  # это словарь
            0: 'Не указано ❓',  # очень
            1: 'Дама ♀',  # удобная
            2: 'Джентльмен ♂'  # штука
        }
        sex_str = sex[sex_int]  # получаю человеческое название пола

        write_msg(user_id, ("Имя при крещении: " + first_name + " " + last_name))
        write_msg(user_id, ("Пол: " + sex_str))

        r = requests.get(("https://vk.com/foaf.php?id=" + id))  # парсинг?
        soup = BeautifulSoup(r.text, "html.parser")  # получаем инфу
        data = soup.find("ya:created")  # ищем дату создания страницы
        data = str(data)[21:46]  # обрезаем всё лишнее
        date = {
            '01': 'Января',
            '02': 'Февраля',
            '03': 'Марта',
            '04': 'Апреля',
            '05': 'Мая',
            '06': 'Июня',
            '07': 'Июля',
            '08': 'Августа',
            '09': 'Сентября',
            '10': 'Октября',
            '11': 'Ноября',
            '12': 'Декабря'
        }

        data = data[0:4] + " год " + str(int(data[8:10])) + " " + date[data[5:7]] + " " + data[11:16] + " по МСК"
        write_msg(user_id, ("⏳Дата создания страницы:\n " + data))  # Профит!

        friends = response[0]['counters']['friends']

        write_msg(user_id, ("Товарищи пользователя: " + str(friends)))  # Профит!

        write_msg(user_id, ("Id при создании: id"+id))
    except:
        pass

# НОВОСТИ
def news(user_id):
    write_msg(user_id, "📰Актуальные новости:")
    url = 'https://yandex.ru'
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html.parser')
    i = 1
    news_list = ''
    for link in soup.find_all('a')[16:21]:
        news_list += (str(i) + ". " + link.text + "\n\n")
        i += 1
    write_msg(user_id, news_list)
    write_msg(user_id, 'Если хотите почитать подробнее об одной из новостей, напишите "Н" и номер новости')

# НОВОСТИ
def news_deep(user_id, message):
    if len(message) == 2:
        n = int(message[1])
        if n > 0 and n < 6:
            url = 'https://yandex.ru'
            r = requests.get(url)
            soup = BeautifulSoup(r.text, 'html.parser')
            link = soup.find_all('a')[n + 15]
            write_msg(user_id, link.text)
            write_msg(user_id, link.get('href'))
        else:
            write_msg(user_id, "Недопустимый номер новости")
    else:
        write_msg(user_id, "Некорректная запись")

#Переводчик
def translate_to_english(go_translate):
    if go_translate == 1:
        zapros = response
        translating = True
        while translating == True:
            try:
                if zapros == "й":
                    go_translate = 0
                    translating = False
                    break
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Загрузка...",
                                                    'random_id': 0})
                zapros_bez_probelov = zapros.replace(" ", "+")
                print(zapros_bez_probelov)
                try:
                    try:
                        #print(1/0)
                        translator_url = "https://www.google.com/search?ei=63vtXuTpAcmtrgSX9KHAAQ&q=google+translate+"+zapros_bez_probelov+ "&oq=google+translate+"+ zapros_bez_probelov + "&gs_lcp=CgZwc3ktYWIQAzICCAAyAggAMgIIADIGCAAQFhAeMgYIABAWEB4yBggAEBYQHjIGCAAQFhAeMgYIABAWEB4yBggAEBYQHjIGCAAQFhAeOgcIABBHELADUNYSWJcYYPEbaAFwAHgAgAFLiAGKApIBATSYAQCgAQGqAQdnd3Mtd2l6uAEC&sclient=psy-ab&ved=0ahUKEwiki9zAs4_qAhXJlosKHRd6CBgQ4dUDCAw&uact=5"
                        translate_page = requests.get(translator_url, headers=headers)
                        time.sleep(2)
                        soup1 = BeautifulSoup(translate_page.content, 'html.parser')
                        otvet_translate=soup1.findAll("pre", {"class": "tw-data-text", "class": "tw-text-large", "class": "XcVN5d", "class": "tw-ta", "data-placeholder": "Перевод", "id": "tw-target-text", "style": "text-align:left"})
                    except:
                        #print(1/0)
                        translator_url = "https://www.google.com/search?ei=Q5PtXsCUNcOqrgTiuJTIAg&q=translate+"+zapros_bez_probelov+"&oq=translate+"+zapros_bez_probelov+"&gs_lcp==CgZwc3ktYWIQA1DpVViLYWDzZGgBcAB4AIABTYgBvQOSAQE3mAEAoAEBqgEHZ3dzLXdpeg&sclient=psy-ab&ved=0ahUKEwiAwtniyY_qAhVDlYsKHWIcBSkQ4dUDCAw&uact=5"
                        translate_page = requests.get(translator_url, headers=headers)
                        time.sleep(2)
                        soup1 = BeautifulSoup(translate_page.content, 'html.parser')
                        otvet_translate=soup1.findAll("pre", {"class": "tw-data-text", "class": "tw-text-large", "class": "XcVN5d", "class": "tw-ta", "data-placeholder": "Перевод", "id": "tw-target-text", "style": "text-align:left"})
                except:
                    otvet_translate="Не могу обработать запрос. Попробуй ввести что-нибудь другое \n (Для выхода напиши й )"

                vk_session.method('messages.send', {'user_id': event.user_id, 'message': otvet_translate[0].text, 'random_id': 0})
                go_translate = 0
                translating = False
            except:
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Не могу обработать запрос. Попробуй ввести что-нибудь другое \n (Для выхода напиши й )",
                                                    'random_id': 0})
                translating = False
    else:
        go_translate = 1
        vk_session.method('messages.send',
                          {'user_id': event.user_id, 'message': 'Что ты хочешь перевести? \n (Для выхода напиши й )',
                           'random_id': 0})
    return(go_translate)

#Курс валют
def exchange_rates():
    otvet_exchange_rates=""
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36'}

    DOLLAR_RUB = 'https://www.google.com/search?q=%D0%94%D0%BE%D0%BB%D0%BB%D0%B0%D1%80+%D0%BA+%D1%80%D1%83%D0%B1%D0%BB%D1%8E&oq=%D0%94%D0%BE%D0%BB%D0%BB%D0%B0%D1%80+%D0%BA+%D1%80%D1%83%D0%B1%D0%BB%D1%8E&aqs=chrome..69i57j0l7.3053j1j7&sourceid=chrome&ie=UTF-8'
    usd_page = requests.get(DOLLAR_RUB, headers=headers)
    soup1 = BeautifulSoup(usd_page.content, 'html.parser')
    convert_usd = soup1.findAll("span", {"class": "DFlfde", "class": "SwHCTb", "data-precision": 2})
    rub_za_usd = float(convert_usd[0].text.replace(",", "."))
    otvet_exchange_rates= otvet_exchange_rates+ "1 USD = " + str(rub_za_usd) + " RUB" + "\n"

    EURO_RUB = 'https://www.google.com/search?q=%D0%B5%D0%B2%D1%80%D0%BE+%D0%BA+%D1%80%D1%83%D0%B1%D0%BB%D1%8E&oq=%D0%B5%D0%B2%D1%80%D0%BE+%D0%BA+%D1%80%D1%83%D0%B1%D0%BB%D1%8E&aqs=chrome..69i57j0l7.4274j1j9&sourceid=chrome&ie=UTF-8'
    euro_page = requests.get(EURO_RUB, headers=headers)
    soup2 = BeautifulSoup(euro_page.content, 'html.parser')
    convert_euro = soup2.findAll("span", {"class": "DFlfde", "class": "SwHCTb", "data-precision": 2})
    rub_za_euro = float(convert_euro[0].text.replace(",", "."))
    otvet_exchange_rates= otvet_exchange_rates+ "1 EURO = " + str(rub_za_euro) + " RUB" + "\n"


    UAH_RUB = 'https://www.google.com/search?q=%D0%B3%D1%80%D0%B8%D0%B2%D0%BD%D1%8B+%D0%BA+%D1%80%D1%83%D0%B1%D0%BB%D1%8E&oq=%D0%B3%D1%80%D0%B8%D0%B2%D0%BD%D1%8B+%D0%BA+%D1%80%D1%83%D0%B1%D0%BB%D1%8E&aqs=chrome..69i57j0l7.2707j1j9&sourceid=chrome&ie=UTF-8'
    uah_page = requests.get(UAH_RUB, headers=headers)
    soup3 = BeautifulSoup(uah_page.content, 'html.parser')
    convert_uah = soup3.findAll("span", {"class": "DFlfde", "class": "SwHCTb", "data-precision": 2})
    rub_za_uah = float(convert_uah[0].text.replace(",", "."))
    otvet_exchange_rates= otvet_exchange_rates+ "1 UAH = " + str(rub_za_uah) + " RUB" + "\n"

    BTC_USD = 'https://www.google.com/search?ei=SF_tXsf-O8qxrgSJm5_gBw&q=%D0%B1%D0%B8%D1%82%D0%BA%D0%BE%D0%B8%D0%BD+%D0%BA+%D0%B4%D0%BE%D0%BB%D0%BB%D0%B0%D1%80%D1%83&oq=%D0%B1%D0%B8%D1%82%D0%BA%D0%BE%D0%B8%D0%BD+%D0%BA+%D0%B4&gs_lcp=CgZwc3ktYWIQAxgAMgUIABCxAzICCAAyAggAMgIIADICCAAyAggAMgIIADICCAAyAggAMgIIADoHCAAQRxCwAzoECAAQQzoGCAAQFhAeOgkIABBDEEYQggI6CAgAEBYQChAeOgkIABANEEYQggI6BAgAEA1Qvo8yWIWcMmDqoTJoA3AAeACAAUqIAYMDkgEBNpgBAKABAaoBB2d3cy13aXq4AQI&sclient=psy-ab'
    btc_page = requests.get(BTC_USD, headers=headers)
    soup4 = BeautifulSoup(btc_page.content, 'html.parser')
    convert_btc = soup4.findAll("span", {"class": "DFlfde", "class": "SwHCTb", "data-precision": 2})
    usd_za_btc=convert_btc[0].text.replace(",", ".")
    otvet_exchange_rates= otvet_exchange_rates+ "1 BTC = " + str(usd_za_btc) + " USD" + "\n"

    return otvet_exchange_rates

#Погода
def detect_wind(wind_speed):
    if wind_speed <= 0.2:
        wind_type = "штиль"
    elif 0.2 < wind_speed <= 3.3:
        wind_type = "легкий"
    elif 3.3 < wind_speed <= 5.4:
        wind_type = "слабый"
    elif 5.4 < wind_speed <= 7.9:
        wind_type = "умеренный"
    elif 7.9 < wind_speed <= 10.7:
        wind_type = "свежий"
    elif 10.7 < wind_speed <= 13.8:
        wind_type = "сильный"
    elif 13.8 < wind_speed <= 17.1:
        wind_type = "крепкий"
    elif 17.1 < wind_speed <= 20:
        wind_type = "очень крепкий"
    elif 20 < wind_speed <= 24.4:
        wind_type = "шторм"
    elif 24.4 < wind_speed < 28.4:
        wind_type = "сильный шторм"
    elif 28.4 < wind_speed <= 32.6:
        wind_type = "жестокий шторм"
    elif 32.6 < wind_speed:
        wind_type = "ураган"
    return wind_type

def clothes(temperature,wind_speed):
    current_temp = temperature - 0.8*(wind_speed)
    if wind_speed>14:
        pogoda_clothing="На улице сильный ветер, из дома лучше не выходить"
    elif 35<current_temp :
        pogoda_clothing="На улице слишком жарко, из дома лучше не выходить"
    elif 22<current_temp<=35 :
        pogoda_clothing="На улице жарко. Надевай футболку и шорты"
    elif 18<current_temp<=22 :
        pogoda_clothing="На улице тепло. Надевай футболку и штаны"
    elif 12<current_temp<=18 :
        pogoda_clothing="На улице свежо. Надевай ветровку"
    elif 4<current_temp<=12 :
        pogoda_clothing="На улице прохладно. Надевай куртку"
    elif -10<current_temp<=4 :
        pogoda_clothing="На улице холодно. Надевай пуховик"
    elif -25<current_temp<=-10 :
        pogoda_clothing="На улице морозы. Надевай теплый пуховик"
    elif current_temp<=-25 :
        pogoda_clothing="На улице слишком холодно, из дома лучше не выходить"
    return pogoda_clothing

def weather_take(pogod):
    if pogod == 1:
        city = response
        pogoda = True
        while pogoda == True:
            try:
                if city == "й":
                    pogod = 0
                    pogoda = False
                    break

                # html погода

                # OWM погода
                owm = pyowm.OWM('6d00d1d4e704068d70191bad2673e0cc', language='ru')
                observation = owm.weather_at_place(city)
                w_weather = observation.get_weather()
                temperature = w_weather.get_temperature('celsius')['temp']
                temperature = round(temperature, 1)
                wind_speed = w_weather.get_wind()['speed']
                wind_speed = round(wind_speed, 1)

                # определение названия ветра
                wind_type = ""
                wind_type = detect_wind(wind_speed)

                #прогноз одежды
                clothes(temperature,wind_speed)
                pogoda_clothing = clothes(temperature,wind_speed)

                otvet_pogoda = "В городе " + str(city).title() + " сейчас " + str(
                    temperature) + "℃. Ветер: " + wind_type + " (" + str(wind_speed) + " м/с); " + str(
                    w_weather.get_detailed_status()) + "\n"
                otvet_pogoda=otvet_pogoda + "Совет: " + pogoda_clothing
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': otvet_pogoda, 'random_id': 0})
                pogod = 0
                pogoda = False
            except pyowm.exceptions.api_response_error.NotFoundError:
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Такого города не существует, попробуй ещё раз. \n (Для выхода напиши й )",
                                                    'random_id': 0})
                pogoda = False
    else:
        pogod = 1
        vk_session.method('messages.send',
                          {'user_id': event.user_id, 'message': 'В каком городе ты хочешь узнать погоду? \n (Для выхода напиши й )',
                           'random_id': 0})
    return(pogod)

кнб=0
мемы=0
видео=0
музыка=0
настройки=0
монета=0
погода=0
pogod=0
go_translate=0

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        print('Сообщение пришло в: ' + str(datetime.strftime(datetime.now(), "%H:%M:%S")))
        print('Текст сообщения: ' + str(event.text))
        print(event.user_id)
        response = event.text.lower()
        if event.from_user and not (event.from_me):

            #Самое начало
            if response == "начать":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'МЕМ БОТ ВКЛЮЧЕН. Чтобы зайти в меню, напиши  - "Меню",', 'random_id': 0})

            #Меню
            elif response == "меню":

                кнб=0
                мемы=0
                видео=0
                музыка=0
                настройки=0
                монета=0
                погода=0
                курс=0

                st= 'Чтобы получить мемы, напиши - "Мемы". \r\n \r\n Чтобы получить видео, напиши - "Видео". \r\n \r\n Чтобы получить музыку, напиши - "Музыка". \r\n \r\n Чтобы посмотреть настройки мемов, напиши - "Настройки". \r\n \r\n Чтобы подкинуть монетку, напиши - "Монета". \r\n \r\n Чтобы сыграть в КНБ, напиши -"КНБ". \r\n \r\n Чтобы узнать погоду, напиши - "Погода".\r\n \r\n Чтобы узнать текущий курс основных валют, напиши - "Курс".\r\n \r\n Чтобы воспользоваться переводчиком (ENG-RUS; RUS-ENG), напиши - "Перевод". \r\n \r\n Чтобы узнать недавнии новости, напиши - "Новости". \r\n \r\n Чтобы узнать информацию про владельца страницы, напиши - "Инфа" '

                vk_session.method('messages.send', {'user_id': event.user_id, 'message': st , 'random_id': 0})

            #Мемы
            elif response == "мемы" and( видео !=1 and кнб !=1 and музыка!=1 and настройки!=1 and монета!=1 and погода!=1):
                p=23
                мемы = 1
                stroka = "photo-163452344_4573899"+str(p)+"%2Falbum-163452344_00%2Frev"
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. ", "attachment": stroka,'random_id': 0})
            elif response == "+" and мемы == 1 :
                p-=1
                stroka = "photo-163452344_4573899"+str(p)+"%2Falbum-163452344_00%2Frev"
                if p>17 :
                    vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", "attachment": stroka,'random_id': 0})
                else : vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Мемы кончились",'random_id': 0})

            #Видео
            elif (response == "видео" and( мемы !=1 and кнб !=1 and музыка!=1 and настройки!=1 and монета!=1 and погода!=1))or (response == "+" and видео == 1 ):
                x= random.randint(500,606)
                видео = 1
                stroka="video-134895321_456251"+str(x)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", "attachment": stroka,'random_id': 0})

            #Музыка
            elif (response == "музыка" and(видео !=1 and мемы !=1 and кнб !=1 and  настройки!=1 and монета!=1 and погода!=1)) or (response == "+" and музыка ==1 ):
                k= random.randint(600,924)
                музыка = 1
                stroka="audio-192611626_456241"+str(k)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", "attachment": stroka + "photo-27895931_457419537",'random_id': 0})
                vk_session.method("messages.send", {"peer_id": event.user_id, "attachment":"photo-27895931_457419537",'random_id': 0})

            #Настройки интересов Мемов
            elif response == "настройки":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Эта функция пока не доступна\r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})

            #Подкидывание монеты
            elif (response == "монета" and (видео !=1 and мемы !=1 and кнб !=1 and музыка!=1 and настройки!=1 and погода!=1)) or (response =="+" and монета == 1 ):
                a=random.randint(0,3)
                монета =1
                if a==1:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Орел \r\n Если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Решка \r\n Если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})


            #Камень Ножницы Бумага
            elif response == "кнб" and(видео !=1 and мемы !=1 and музыка!=1 and настройки!=1 and монета!=1 and погода!=1):
                кнб = 1
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Напиши мне "К"(Камень), "Н"(Ножницы) или "Б"(Бумага)\r\n Чтобы вернутся в меню, напиши  - "Меню".', 'random_id': 0})

            #Игра
            elif (response == "к" or response == "н" or response == "б")and(кнб == 1) :
                a=random.randint(0,4)
                if a==1 :
                    st="к"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Камень✊🏻', 'random_id': 0})
                elif a==2:
                    st="н"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ножницы✌🏻', 'random_id': 0})
                else :
                    st="б"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Бумага🖐🏻', 'random_id': 0})

                if st==response:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Ничья🤡 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага). \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})
                elif (st=="б" and response=="н") or (st=="н" and response=="к") or (st=="к" and response=="б"):
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Ты победил👍🏻 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага). \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Ты проиграл😥 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага). \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})

            #Погода
            elif (response == "погода" or pogod==1) and(видео !=1 and мемы !=1 and музыка!=1 and настройки!=1 and монета!=1 and кнб!= 1) :
                pogod = weather_take(pogod)

            #Курс USD, EUR, UAH, BTC
            elif (response == "курс"  or response =="курсы") and(видео !=1 and мемы !=1 and музыка!=1 and настройки!=1 and монета!=1 and кнб!= 1 and погода!=1):
                курс = 1
                otvet_curs=exchange_rates()
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': otvet_curs,
                                                    'random_id': 0})

            #Переводчик
            elif (response == "перевод" or go_translate==1):
                go_translate = translate_to_english(go_translate)

            #Новости
            elif response == "новости":
                news(event.user_id)
            elif (response.find("н") == 0):
                news_deep(event.user_id, event.text)

            #Информация про владельца странички
            elif response == "инфа":
                инфа = 1
                write_msg(event.user_id, 'Отправьте ссылку на человека, которого нужно ПрОаНаЛиЗиРоВаТь \n (Для выхода напиши й )')
            elif инфа == 1:
                info(event.user_id, event.text)
                инфа = 0
            elif инфа == 1 and response == "й":
                инфа = 0

            else :
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'У меня нет такой команды.', 'random_id': 0})
