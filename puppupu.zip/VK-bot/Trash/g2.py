from vk_api.longpoll import VkLongPoll, VkEventType
import vk_api
from datetime import datetime
import random
import time


token = "b99dd675ad7d4febd15c45e6d6ea0edcdbc100b19a4c4281d819ad9025e3bf3912c8927caaa83bc2ff9e5"
vk_session = vk_api.VkApi(token=token)

session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        print('Сообщение пришло в: ' + str(datetime.strftime(datetime.now(), "%H:%M:%S")))
        print('Текст сообщения: ' + str(event.text))
        print(event.user_id)
        response = event.text.lower()
        if event.from_user and not (event.from_me):
            if response == "начать":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'МЕМ БОТ ВКЛЮЧЕН. Чтобы ознакомиться с командами, напиши  - "Help",', 'random_id': 0})
            elif response == "help":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': 'Чтобы получить мемы, напиши - "Мемы" \r\n Чтобы посмотреть настройки мемов, напиши - "Настройки" \r\n Чтобы посмотреть понравившиеся мемы, напиши  - "Лайк" \r\n Чтобы подкинуть монетку, напиши - "Монета"\r\n Чтобы сыграть в КНБ, напиши -"КНБ"', 'random_id': 0})
            elif response == "мемы":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Эта функция пока не доступна', 'random_id': 0})
            elif response == "лайк":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Эта функция пока не доступна', 'random_id': 0})
            elif response == "настройки":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Эта функция пока не доступна', 'random_id': 0})
            elif response == "монета":
                a=random.randint(0,3)
                if a==1:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Орел', 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Решка', 'random_id': 0})
            elif response == "кнб":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Напиши мне "К"(Камень), "Н"(Ножницы) или "Б"(Бумага)', 'random_id': 0})
            elif response == "к" or response == "н" or response == "б" :
                a=random.randint(0,4)
                if a==1 :
                    st="к"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Камень✊🏻', 'random_id': 0})
                elif a==2:
                    st="н"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ножницы✌🏻', 'random_id': 0})
                else :
                    st="б"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Бумага🖐🏻', 'random_id': 0})

                if st==response:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ничья🤡', 'random_id': 0})
                elif (st=="б" and response=="н") or (st=="н" and response=="к") or (st=="к" and response=="б"):
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ты победил👍🏻', 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ты проиграл😥', 'random_id': 0})
