print("hello from katy")
print("hello from sen9")
print("hello from sergei")
n=0
