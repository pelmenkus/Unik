from vk_api.longpoll import VkLongPoll, VkEventType
import vk_api
from datetime import datetime
import random
import time


token = "e7867f2cfba3742401ec435b24740c0082edd3473fae331ba537f376e3b930f04f6e46e17d1d0b81b3c59"
vk_session = vk_api.VkApi(token=token)

session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)

muz=0
vid=0
mem=0
for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        print('Сообщение пришло в: ' + str(datetime.strftime(datetime.now(), "%H:%M:%S")))
        print('Текст сообщения: ' + str(event.text))
        print(event.user_id)
        response = event.text.lower()
        if event.from_user and not (event.from_me):
            if response == "начать":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'МЕМ БОТ ВКЛЮЧЕН. Чтобы ознакомиться с командами, напиши  - Help,', 'random_id': 0})
            elif response == "help":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': 'Чтобы получить мемы, напиши - "Мемы" \r\n Чтобы получить видео, напиши - Видео \r\n Чтобы получить музыку, напиши - Музыка \r\n Чтобы посмотреть настройки мемов, напиши - Настройки \r\n  Чтобы подкинуть монетку, напиши - Монета\r\n Чтобы сыграть в Камень Ножницы Бумага, напиши -КНБ', 'random_id': 0})
            elif response == "мемы":
                mem=1
                vid=0
                muz=0
                p=23
                stroka = "photo-163452344_4573899"+str(p)+"%2Falbum-163452344_00%2Frev"
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми + ", "attachment": stroka,'random_id': 0})
            elif (response == "+") and (mem==1) :
                p-=1
                stroka = "photo-163452344_4573899"+str(p)+"%2Falbum-163452344_00%2Frev"
                if p>17 :
                    vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми + ", "attachment": stroka,'random_id': 0})
                else : vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Мемы кончились",'random_id': 0})
            elif response == "видео" or ((response == "+") and (vid==1)):
                vid=1
                muz=0
                mem=0
                x= random.randint(500,606)
                stroka="video-134895321_456251"+str(x)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми + ", "attachment": stroka,'random_id': 0})
            elif response == "музыка" or ((response == "+") and (muz==1)):
                muz=1
                vid=0
                mem=0
                k= random.randint(600,924)
                stroka="audio-192611626_456241"+str(k)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми + ", "attachment": stroka + "photo-27895931_457419537",'random_id': 0})
                vk_session.method("messages.send", {"peer_id": event.user_id, "attachment":"photo-27895931_457419537",'random_id': 0})
            elif response == "настройки":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Эта функция пока не доступна', 'random_id': 0})
            elif response == "монета":
                a=random.randint(0,3)
                if a==1:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Орел', 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Решка', 'random_id': 0})
            elif response == "кнб":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Напиши мне "К"(Камень), Н-(Ножницы) или Б-(Бумага)', 'random_id': 0})
            elif response == "к" or response == "н" or response == "б" :
                a=random.randint(0,4)
                if a==1 :
                    st="к"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Камень✊🏻', 'random_id': 0})
                elif a==2:
                    st="н"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ножницы✌🏻', 'random_id': 0})
                else :
                    st="б"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Бумага🖐🏻', 'random_id': 0})

                if st==response:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ничья🤡', 'random_id': 0})
                elif (st=="б" and response=="н") or (st=="н" and response=="к") or (st=="к" and response=="б"):
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ты победил👍🏻', 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ты проиграл😥', 'random_id': 0})
