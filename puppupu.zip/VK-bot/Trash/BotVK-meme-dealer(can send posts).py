from vk_api.longpoll import VkLongPoll, VkEventType
import vk_api
from datetime import datetime
import random
import time
import requests

version = 5.110
token = "e7867f2cfba3742401ec435b24740c0082edd3473fae331ba537f376e3b930f04f6e46e17d1d0b81b3c59"
vk_session = vk_api.VkApi(token=token)
session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)

def response_memes(amount_of_response, domain):
    amount_of_memes = int(amount_of_response)
    memes = take_posts(amount_of_memes, domain)
    for i in range(amount_of_memes):
        if memes[i]['likes']['count'] / memes[i]['views']['count'] >= 0.05:
            vk_session.method("messages.send", {"peer_id": event.user_id,"attachment": "wall" + str(memes[i]['from_id']) + "_" + str(memes[i]['id']),'random_id': 0})
        else:
            vk_session.method("messages.send", {"peer_id": event.user_id,"message": "непригодный мем", 'random_id': 0})

def take_posts(amount, domain):
    meme_token = '1cb35abd1cb35abd1cb35abd9e1cc1f04911cb31cb35abd4258105755c05baf06d0455a'
    version = 5.109
    #domain = 'reddit'
    offset = 0
    count = 1
    all_posts = []
    while offset < amount:
        response_memes = requests.get('https://api.vk.com/method/wall.get',
                                      params={
                                          'access_token': meme_token,
                                          'v': version,
                                          'domain': domain,
                                          'count': count,
                                          'offset': offset
                                      })
        get_memes = response_memes.json()['response']['items']
        offset += 1
        all_posts.extend(get_memes)
    return (all_posts)

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        print('Сообщение пришло в: ' + str(datetime.strftime(datetime.now(), "%H:%M:%S")))
        print('Текст сообщения: ' + str(event.text))
        print(event.user_id)
        response = event.text.lower() + ' trash trash'
        meme_domain = response.split()[2]
        amount_of_response = response.split()[1]
        response = response.split()[0]
        if event.from_user and not (event.from_me):

            if response == "help":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': 'Чтобы получить мемы, напиши - "Мемы  (количество мемов) (домен группы)" \r\n Чтобы получить видео, напиши - "Видео" \r\n Чтобы получить музыку, напиши - "Музыка" \r\n Чтобы посмотреть настройки мемов, напиши - "Настройки" \r\n  Чтобы подкинуть монетку, напиши - "Монета"\r\n Чтобы сыграть в КНБ, напиши -"КНБ"', 'random_id': 0})
            elif response == "мемы":
                response_memes(amount_of_response, meme_domain)
            elif response == "видео" or response == "++":
                x= random.randint(500,606)
                stroka="video-134895321_456251"+str(x)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '++' ", "attachment": stroka,'random_id': 0})
            elif response == "музыка" or response == "+++":
                k= random.randint(600,924)
                stroka="audio-192611626_456241"+str(k)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+++' ", "attachment": stroka + "photo-27895931_457419537",'random_id': 0})
                vk_session.method("messages.send", {"peer_id": event.user_id, "attachment":"photo-27895931_457419537",'random_id': 0})
            elif response == "настройки":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Эта функция пока не доступна', 'random_id': 0})
            elif  response == "++" :
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Эта функция пока не доступна', 'random_id': 0})
            elif response == "монета":
                a=random.randint(0,3)
                if a==1:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Орел', 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Решка', 'random_id': 0})
            elif response == "кнб":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Напиши мне "К"(Камень), "Н"(Ножницы) или "Б"(Бумага)', 'random_id': 0})
            elif response == "к" or response == "н" or response == "б" :
                a=random.randint(0,4)
                if a==1 :
                    st="к"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Камень✊🏻', 'random_id': 0})
                elif a==2:
                    st="н"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ножницы✌🏻', 'random_id': 0})
                else :
                    st="б"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Бумага🖐🏻', 'random_id': 0})

                if st==response:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ничья🤡', 'random_id': 0})
                elif (st=="б" and response=="н") or (st=="н" and response=="к") or (st=="к" and response=="б"):
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ты победил👍🏻', 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ты проиграл😥', 'random_id': 0})
            elif response != "начать":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'МЕМ БОТ ВКЛЮЧЕН. Чтобы ознакомиться с командами, напиши  - "Help",', 'random_id': 0})
