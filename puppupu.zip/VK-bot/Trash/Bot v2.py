import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType

token = "a49bf03f13222bf22bc498bd26809ef7471f2d1ade0235e880e5bf6d0c98013248f1c79c103c49249c0e2"
vk = vk_api.VkApi(token=token)
longpoll = VkLongPoll(vk)

def write_msg(id, mess):
    vk.method('messages.send', {'user_id':id, 'message': mess, 'random_id' : 0})

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        if event.to_me:
            request = event.text
            write_msg(event.user_id,request)
