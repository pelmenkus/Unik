# Ссылка на бота
# https://vk.com/public196416621
# 184763436

import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType
from bs4 import BeautifulSoup
import random
import requests


def write_msg(user_id, message):
    vk.method('messages.send', {'user_id': user_id, 'message': message, 'random_id': random.getrandbits(64)})


def info(user_id, message):  # шобы работало нужно import bs4 и requests
    try:
        message = message[5:len(message)]
        id = message[message.rfind('/') + 1:len(message)]  # оставляю только id пользователя или его "ник"
        response = vk.method('users.get', {'user_ids': id, 'fields': 'sex, counters'})  # получаю инфу о человеке
        id = str(response[0]['id'])  # теперь это именно id
        # print(id)

        first_name = response[0]['first_name']  # выкапываю имя
        last_name = response[0]['last_name']  # вытаскиваю фамилию

        sex_int = response[0]['sex']  # выкорчовываю пол (0, 1, 2)
        sex = {  # это словарь
            0: 'Сказочная тварь ❓',  # очень
            1: 'Дама ♀',  # удобная
            2: 'Джентльмен ♂'  # штука
        }
        sex_str = sex[sex_int]  # получаю человеческое название пола

        write_msg(user_id, ("Имя при крещении: " + first_name + " " + last_name))
        write_msg(user_id, ("Пол: " + sex_str))

        r = requests.get(("https://vk.com/foaf.php?id=" + id))  # парсинг?
        soup = BeautifulSoup(r.text, "html.parser")  # получаем инфу
        data = soup.find("ya:created")  # ищем дату создания страницы
        data = str(data)[21:46]  # обрезаем всё лишнее
        date = {
            '01': 'Января',
            '02': 'Февраля',
            '03': 'Марта',
            '04': 'Апреля',
            '05': 'Мая',
            '06': 'Июня',
            '07': 'Июля',
            '08': 'Августа',
            '09': 'Сентября',
            '10': 'Октября',
            '11': 'Ноября',
            '12': 'Декабря'
        }

        data = data[0:4] + " год " + str(int(data[8:10])) + " " + date[data[5:7]] + " " + data[11:16] + " по МСК"
        write_msg(user_id, ("⏳Дата создания страницы:\n " + data))  # Профит!

        friends = response[0]['counters']['friends']
        write_msg(user_id, ("Товарищи пользователя: " + str(friends)))  # Профит!
    except():
        write_msg(user_id, "⚠Что-то пошло не так...⚠")


def news(user_id):
    write_msg(user_id, "📰Актуальные новости:")
    url = 'https://yandex.ru'
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html.parser')
    i = 1
    news_list = ''
    for link in soup.find_all('a')[16:21]:
        news_list += (str(i) + ". " + link.text + "\n" + link.get('href') + "\n\n")
        i += 1
    write_msg(user_id, news_list)

file = shelve.open('database')



token = 'fde48d538efc5489b9d694911cce2542c8fb21d6d1870a8b45f02e42792a588419a8a62e67839b1631342'

vk = vk_api.VkApi(token=token)

longpoll = VkLongPoll(vk)

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        if event.to_me:
            response = event.text.lower()
            if response == "новости":
                news(event.user_id)
            elif response == "инфа":
                write_msg(event.user_id, 'Отправьте "Инфа" и ссылку на человека, которого нужно ПрОаНаЛиЗиРоВаТь')
            elif response.find("инфа") == 0:
                info(event.user_id, event.text)
            else:
                write_msg(event.user_id, 'Чё?')
