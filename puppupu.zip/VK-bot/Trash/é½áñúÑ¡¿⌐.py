import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType
import data
from datetime import datetime

token="d8d8b3209b45be7c733e9dfe2472d186c525d32baf6202f7874bf518cab3912a40a428b14a81f1ac390bc"
vk_session = vk_api.VkApi(token=token)

session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)

def sender(id, text):
    vk_session.method('messages.send', {'user_id' : id, 'message' : text, 'random_id' : 0})

while True:
    for event in longpoll.listen():
        if event.type == VkEventType.MESSAGE_NEW:
            print('Сообщение пришло в: ' + str(datetime.strftime(datetime.now(), "%H:%M:%S")))
            if event.to_me:
                msg = event.text
                id = event.user_id
                sender(id, msg)
