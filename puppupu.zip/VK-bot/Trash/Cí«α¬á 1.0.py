from vk_api.longpoll import VkLongPoll, VkEventType
import vk_api
from datetime import datetime
import random
import time
import pyowm #pip pyowm install -- для OWM погоды; устанавливать версию 2.10.0 !
import requests
from bs4 import BeautifulSoup as BS #pip install beautifulsoup4 -- для html погоды


token = "b99dd675ad7d4febd15c45e6d6ea0edcdbc100b19a4c4281d819ad9025e3bf3912c8927caaa83bc2ff9e5"
vk_session = vk_api.VkApi(token=token)

session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)


#Погода
def detect_wind(wind_speed):
    if wind_speed <= 0.2:
        wind_type = "штиль"
    elif 0.2 < wind_speed <= 3.3:
        wind_type = "легкий"
    elif 3.3 < wind_speed <= 5.4:
        wind_type = "слабый"
    elif 5.4 < wind_speed <= 7.9:
        wind_type = "умеренный"
    elif 7.9 < wind_speed <= 10.7:
        wind_type = "свежий"
    elif 10.7 < wind_speed <= 13.8:
        wind_type = "сильный"
    elif 13.8 < wind_speed <= 17.1:
        wind_type = "крепкий"
    elif 17.1 < wind_speed <= 20:
        wind_type = "очень крепкий"
    elif 20 < wind_speed <= 24.4:
        wind_type = "шторм"
    elif 24.4 < wind_speed < 28.4:
        wind_type = "сильный шторм"
    elif 28.4 < wind_speed <= 32.6:
        wind_type = "жестокий шторм"
    elif 32.6 < wind_speed:
        wind_type = "ураган"
    return wind_type

def clothes(temperature,wind_speed):
    current_temp = temperature - 0.8*(wind_speed)
    if wind_speed>14:
        pogoda_clothing="На улице сильный ветер, из дома лучше не выходить"
    elif 35<current_temp :
        pogoda_clothing="На улице слишком жарко, из дома лучше не выходить"
    elif 22<current_temp<=35 :
        pogoda_clothing="На улице жарко. Надевай футболку и шорты"
    elif 18<current_temp<=22 :
        pogoda_clothing="На улице тепло. Надевай футболку и штаны"
    elif 12<current_temp<=18 :
        pogoda_clothing="На улице свежо. Надевай ветровку"
    elif 4<current_temp<=12 :
        pogoda_clothing="На улице прохладно. Надевай куртку"
    elif -10<current_temp<=4 :
        pogoda_clothing="На улице холодно. Надевай пуховик"
    elif -25<current_temp<=-10 :
        pogoda_clothing="На улице морозы. Надевай теплый пуховик"
    elif current_temp<=-25 :
        pogoda_clothing="На улице слишком холодно, из дома лучше не выходить"
    return pogoda_clothing


def weather_take(pogod):
    if pogod == 1:
        city = response
        pogoda = True
        while pogoda == True:
            try:
                if city == "й":
                    pogod = 0
                    pogoda = False
                    break
                # html погода
                continue_with_descript=1
                descript=" "
                site_url="https://sinoptik.ua/погода-"+city
                try:
                    r = requests.get(site_url)
                    html = BS(r.content, 'html.parser')
                    for el in html.select('#content'):
                        descript = el.select('.wDescription .description')[0].text
                except:
                    continue_with_descript=0
                # OWM погода
                owm = pyowm.OWM('6d00d1d4e704068d70191bad2673e0cc', language='ru')
                observation = owm.weather_at_place(city)
                w_weather = observation.get_weather()
                temperature = w_weather.get_temperature('celsius')['temp']
                temperature = round(temperature, 1)
                wind_speed = w_weather.get_wind()['speed']
                wind_speed = round(wind_speed, 1)

                # определение названия ветра
                wind_type = ""
                wind_type = detect_wind(wind_speed)

                #прогноз одежды
                clothes(temperature,wind_speed)
                pogoda_clothing = clothes(temperature,wind_speed)

                otvet_pogoda = "В городе " + str(city).title() + " сейчас " + str(
                    temperature) + "℃. Ветер: " + wind_type + " (" + str(wind_speed) + " м/с); " + str(
                    w_weather.get_detailed_status()) + "\n"
                if continue_with_descript == 1:
                    otvet_pogoda = otvet_pogoda +"\n"+"Прогноз:" + descript + "\n" +"\n"
                otvet_pogoda=otvet_pogoda + "Совет: " + pogoda_clothing
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': otvet_pogoda, 'random_id': 0})
                pogod = 0
                pogoda = False
            except pyowm.exceptions.api_response_error.NotFoundError:
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Такого города не существует, попробуй ещё раз. \n (Для выхода напиши й )",
                                                    'random_id': 0})
                pogoda = False
    else:
        pogod = 1
        vk_session.method('messages.send',
                          {'user_id': event.user_id, 'message': 'В каком городе ты живешь? \n (Для выхода напиши й )',
                           'random_id': 0})
    return(pogod)

кнб=0
мемы=0
видео=0
музыка=0
настройки=0
монета=0
погода=0
pogod=0

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        print('Сообщение пришло в: ' + str(datetime.strftime(datetime.now(), "%H:%M:%S")))
        print('Текст сообщения: ' + str(event.text))
        print(event.user_id)
        response = event.text.lower()
        if event.from_user and not (event.from_me):

            #Самое начало
            if response == "начать":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'МЕМ БОТ ВКЛЮЧЕН. Чтобы зайти в меню, напиши  - "Меню",', 'random_id': 0})

            #Меню
            elif response == "меню":
                кнб=0
                мемы=0
                видео=0
                музыка=0
                настройки=0
                монета=0
                погода=0
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': 'Чтобы получить мемы, напиши - "Мемы" \r\n Чтобы получить видео, напиши - "Видео" \r\n Чтобы получить музыку, напиши - "Музыка" \r\n Чтобы посмотреть настройки мемов, напиши - "Настройки" \r\n  Чтобы подкинуть монетку, напиши - "Монета"\r\n Чтобы сыграть в КНБ, напиши -"КНБ"\r\n Чтобу узнать погоду, напиши - "Погода"', 'random_id': 0})

            #Мемы
            elif response == "мемы" and( видео !=1 and кнб !=1 and музыка!=1 and настройки!=1 and монета!=1 and погода!=1):
                p=23
                мемы = 1
                stroka = "photo-163452344_4573899"+str(p)+"%2Falbum-163452344_00%2Frev"
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. ", "attachment": stroka,'random_id': 0})
            elif response == "+" and мемы == 1 :
                p-=1
                stroka = "photo-163452344_4573899"+str(p)+"%2Falbum-163452344_00%2Frev"
                if p>17 :
                    vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", "attachment": stroka,'random_id': 0})
                else : vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Мемы кончились",'random_id': 0})

            #Видео
            elif (response == "видео" and( мемы !=1 and кнб !=1 and музыка!=1 and настройки!=1 and монета!=1 and погода!=1))or (response == "+" and видео == 1 ):
                x= random.randint(500,606)
                видео = 1
                stroka="video-134895321_456251"+str(x)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", "attachment": stroka,'random_id': 0})

            #Музыка
            elif (response == "музыка" and(видео !=1 and мемы !=1 and кнб !=1 and  настройки!=1 and монета!=1 and погода!=1)) or (response == "+" and музыка ==1 ):
                k= random.randint(600,924)
                музыка = 1
                stroka="audio-192611626_456241"+str(k)
                vk_session.method("messages.send", {"peer_id": event.user_id, "message": "Держи, если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", "attachment": stroka + "photo-27895931_457419537",'random_id': 0})
                vk_session.method("messages.send", {"peer_id": event.user_id, "attachment":"photo-27895931_457419537",'random_id': 0})

            #Настройки интересов Мемов
            elif response == "настройки":
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Эта функция пока не доступна\r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})

            #Подкидывание монеты
            elif (response == "монета" and (видео !=1 and мемы !=1 and кнб !=1 and музыка!=1 and настройки!=1 and погода!=1)) or (response =="+" and монета == 1 ):
                a=random.randint(0,3)
                монета =1
                if a==1:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Орел \r\n Если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Решка \r\n Если хочешь еще, жми '+'. \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})


            #Камень Ножницы Бумага
            elif response == "кнб" and(видео !=1 and мемы !=1 and музыка!=1 and настройки!=1 and монета!=1 and погода!=1):
                кнб = 1
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Напиши мне "К"(Камень), "Н"(Ножницы) или "Б"(Бумага)\r\n Чтобы вернутся в меню, напиши  - "Меню".', 'random_id': 0})
            #Игра
            elif (response == "к" or response == "н" or response == "б")and(кнб == 1) :
                a=random.randint(0,4)
                if a==1 :
                    st="к"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Камень✊🏻', 'random_id': 0})
                elif a==2:
                    st="н"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Ножницы✌🏻', 'random_id': 0})
                else :
                    st="б"
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'Бумага🖐🏻', 'random_id': 0})

                if st==response:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Ничья🤡 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага). \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})
                elif (st=="б" and response=="н") or (st=="н" and response=="к") or (st=="к" and response=="б"):
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Ты победил👍🏻 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага). \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message' : "Ты проиграл😥 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага). \r\n Чтобы вернутся в меню, напиши  - 'Меню'.", 'random_id': 0})

            #Погода
            elif (response == "погода" or pogod==1) and(видео !=1 and мемы !=1 and музыка!=1 and настройки!=1 and монета!=1 and кнб!= 1) :
                pogod = weather_take(pogod)
            else :
                vk_session.method('messages.send', {'user_id': event.user_id, 'message' : 'У меня нет такой команды.', 'random_id': 0})
