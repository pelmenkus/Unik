import vk_api
import pyowm #pip pyowm install -- для OWM погоды
import requests
from vk_api.longpoll import VkLongPoll, VkEventType
from bs4 import BeautifulSoup as BS #pip install beautifulsoup4 -- для html погоды

def weather_take(pogod):
    if pogod == 1:
        city = request
        pogoda = True
        while pogoda == True:
            try:
                if city == "й":
                    pogod = 0
                    pogoda = False
                    break
                # html погода
                r = requests.get('https://sinoptik.ua/погода-москва')
                html = BS(r.content, 'html.parser')
                for el in html.select('#content'):
                    descript_msk = el.select('.wDescription .description')[0].text
                # OWM погода
                owm = pyowm.OWM('6d00d1d4e704068d70191bad2673e0cc', language='ru')
                observation = owm.weather_at_place(city)
                w = observation.get_weather()
                temperature = w.get_temperature('celsius')['temp']
                temperature = round(temperature, 1)
                wind_speed = w.get_wind()['speed']
                wind_speed = round(wind_speed, 1)
                # определение названия ветра
                if wind_speed <= 0.2:
                    wind_name = "штиль"
                elif 0.2 < wind_speed <= 3.3:
                    wind_name = "легкий"
                elif 3.3 < wind_speed <= 5.4:
                    wind_name = "слабый"
                elif 5.4 < wind_speed <= 7.9:
                    wind_name = "умеренный"
                elif 7.9 < wind_speed <= 10.7:
                    wind_name = "свежий"
                elif 10.7 < wind_speed <= 13.8:
                    wind_name = "сильный"
                elif 13.8 < wind_speed <= 17.1:
                    wind_name = "крепкий"
                elif 17.1 < wind_speed <= 20:
                    wind_name = "очень крепкий"
                elif 20 < wind_speed <= 24.4:
                    wind_name = "шторм"
                elif 24.4 < wind_speed < 28.4:
                    wind_name = "сильный шторм"
                elif 28.4 < wind_speed <= 32.6:
                    wind_name = "жестокий шторм"
                elif 32.6 < wind_speed:
                    wind_name = "ураган"
                st = "В городе " + str(city_with_large_letter) + " сейчас " + str(
                    temperature) + "℃. Ветер: " + wind_name + " (" + str(wind_speed) + " м/с); " + str(
                    w.get_detailed_status()) + "\n"
                if city == "москва":
                    st = st + descript_msk
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': st, 'random_id': 0})
                pogod = 0
                pogoda = False
            except pyowm.exceptions.api_response_error.NotFoundError:
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Такого города не существует, попробуй ещё раз. \n (Для выхода напиши й )",
                                                    'random_id': 0})
                pogoda = False
    else:
        pogod = 1
        vk_session.method('messages.send',
                          {'user_id': event.user_id, 'message': 'В каком городе ты живешь? \n (Для выхода напиши й )',
                           'random_id': 0})
    return(pogod)

#авторизация вк
token = "cb7bdcbab8f4e5d867ea41b1a3f3db77315620e99c2dbdc7e566137b8b81f864dee11821a84b5efca4dce"
vk_session = vk_api.VkApi(token=token)
session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)



pogod=0
for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:
        city_with_large_letter=event.text
        request = event.text.lower()
        if event.from_user and not (event.from_me):
            if request == "погода" or pogod==1:
                pogod = weather_take(pogod)