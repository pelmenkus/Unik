from vk_api.longpoll import VkLongPoll, VkEventType
import vk_api
from datetime import datetime
import random
import time
import pyowm
import requests
import shelve
from googletrans import Translator  #pip install googletrans
from bs4 import BeautifulSoup  # pip install beautifulsoup4 -- для html погоды
from keyboards import * # это файл с кнопками, он есть на гите

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.106 Safari/537.36'}

token = "b99dd675ad7d4febd15c45e6d6ea0edcdbc100b19a4c4281d819ad9025e3bf3912c8927caaa83bc2ff9e5"
vk_session = vk_api.VkApi(token=token)
session_api = vk_session.get_api()
longpoll = VkLongPoll(vk_session)


def write_msg(user_id, message):
    vk_session.method('messages.send', {'user_id': user_id, 'message': message, 'random_id': random.getrandbits(64)})


# Инфа
def info(user_id, message):  # шобы работало нужно import bs4 и requests
    try:
        id = message[message.rfind('/') + 1:len(message)]  # оставляю только id пользователя или его "ник"
        parsed_response = vk_session.method('users.get',
                                            {'user_ids': id, 'fields': 'sex, counters'})  # получаю инфу о человеке
        id = str(parsed_response[0]['id'])  # теперь это именно id


        first_name = parsed_response[0]['first_name']  # выкапываю имя
        last_name = parsed_response[0]['last_name']  # вытаскиваю фамилию

        sex_int = parsed_response[0]['sex']  # выкорчовываю пол (0, 1, 2)
        sex = {  # это словарь
            0: 'Не указано ❓',  # очень
            1: 'Дама ♀',  # удобная
            2: 'Джентльмен ♂'  # штука
        }
        sex_str = sex[sex_int]  # получаю человеческое название пола

        write_msg(user_id, ("Имя при крещении: " + first_name + " " + last_name))
        write_msg(user_id, ("Пол: " + sex_str))

        r = requests.get(("https://vk.com/foaf.php?id=" + id))  # парсинг?
        soup = BeautifulSoup(r.text, "html.parser")  # получаем инфу
        created_time = soup.find("ya:created")  # ищем дату создания страницы
        created_time = str(created_time)[21:46]  # обрезаем всё лишнее
        date = {
            '01': 'Января',
            '02': 'Февраля',
            '03': 'Марта',
            '04': 'Апреля',
            '05': 'Мая',
            '06': 'Июня',
            '07': 'Июля',
            '08': 'Августа',
            '09': 'Сентября',
            '10': 'Октября',
            '11': 'Ноября',
            '12': 'Декабря'
        }

        created_time = created_time[0:4] + " год " + str(int(created_time[8:10])) + " " + date[created_time[5:7]] + " " + created_time[11:16] + " по МСК"
        write_msg(user_id, ("⏳Дата создания страницы:\n " + created_time))  # Профит!

        friends = parsed_response[0]['counters']['friends']

        write_msg(user_id, ("Товарищи пользователя: " + str(friends)))  # Профит!

        write_msg(user_id, ("Id при создании: id" + id))
    except:
        write_msg(user_id, "⚠Что-то пошло не так...⚠")


# НОВОСТИ
def news(user_id):
    write_msg(user_id, "📰Актуальные новости:")
    url = 'https://yandex.ru'
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html.parser')
    news_number = 1
    news_list = ''
    for link in soup.find_all('a')[16:21]:
        news_list += (str(news_number) + ". " + link.text + "\n\n")
        news_number += 1
    write_msg(user_id, news_list)
    write_msg(user_id, 'Если хотите почитать подробнее об одной из новостей, напишите "Н" и номер новости')


# НОВОСТИ
def news_deep(user_id, message):
    if len(message) == 2:
        n = int(message[1])
        if 0 < n < 6:
            url = 'https://yandex.ru'
            r = requests.get(url)
            soup = BeautifulSoup(r.text, 'html.parser')
            link = soup.find_all('a')[n + 15]
            write_msg(user_id, link.text)
            write_msg(user_id, link.get('href'))
        else:
            write_msg(user_id, "Недопустимый номер новости")
    else:
        write_msg(user_id, "Некорректная запись")


# Переводчик
def translate_to_english(go_translate):
    translator = Translator()
    if go_translate == 1:
        zapros = response
        translating = True
        while translating:
            try:
                if zapros == "й":
                    go_translate = 0
                    break
                try:
                    language=translator.detect(zapros)
                    language=language.lang
                    language=str(language)
                    print(language)
                    if language == "ru":
                        otvet_translate=translator.translate(zapros, src=language, dest='en')
                    elif language == "en":
                        otvet_translate=translator.translate(zapros, src=language, dest='ru')
                    else:
                        otvet_translate=translator.translate(zapros, src=language, dest='ru')
                    otvet_translate=str(otvet_translate.text)

                except:
                    otvet_translate = "Не могу обработать запрос. Попробуй ввести что-нибудь другое"

                vk_session.method('messages.send',
                                  {'user_id': event.user_id, 'message': otvet_translate, 'random_id': 0, 'keyboard': keyboard_to_menu})
                go_translate = 0
                translating = False
            except:
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Не могу обработать запрос. Попробуй ввести что-нибудь другое",
                                                    'random_id': 0, 'keyboard': keyboard_to_menu})
                translating = False
    else:
        go_translate = 1
        vk_session.method('messages.send',
                          {'user_id': event.user_id, 'message': 'Что ты хочешь перевести?',
                           'random_id': 0, 'keyboard': keyboard_to_menu})
    return go_translate


# Курс валют
def exchange_rates():
    otvet_exchange_rates = ""

    main_yandex_url = 'https://yandex.ru'
    r = requests.get(main_yandex_url)
    soup = BeautifulSoup(r.text, 'html.parser')
    rub_za_usd = soup.find_all("span", {"class": "inline-stocks__value_inner"})[0].text.replace(",", ".")
    rub_za_euro = soup.find_all("span", {"class": "inline-stocks__value_inner"})[1].text.replace(",", ".")

    otvet_exchange_rates = otvet_exchange_rates + "1 USD = " + str(rub_za_usd) + " RUB" + "\n"
    otvet_exchange_rates = otvet_exchange_rates + "1 EURO = " + str(rub_za_euro) + " RUB" + "\n"

    UAH_RUB = "https://yandex.ru/news/quotes/10006.html"
    uah_page = requests.get(UAH_RUB, headers=headers)
    soup = BeautifulSoup(uah_page.content, 'html.parser')
    convert_uah = soup.findAll("td", {"class": "quote__value"})
    rub_za_uah = convert_uah[0].text.replace(",", "")
    rub_za_uah = rub_za_uah[:len(rub_za_uah) - 3]
    rub_za_uah = rub_za_uah[0] + "." + rub_za_uah[1:]
    otvet_exchange_rates = otvet_exchange_rates + "1 UAH = " + str(rub_za_uah) + " RUB" + "\n"

    BTC_USD = 'https://www.google.com/search?ei=SF_tXsf-O8qxrgSJm5_gBw&q=%D0%B1%D0%B8%D1%82%D0%BA%D0%BE%D0%B8%D0%BD+%D0%BA+%D0%B4%D0%BE%D0%BB%D0%BB%D0%B0%D1%80%D1%83&oq=%D0%B1%D0%B8%D1%82%D0%BA%D0%BE%D0%B8%D0%BD+%D0%BA+%D0%B4&gs_lcp=CgZwc3ktYWIQAxgAMgUIABCxAzICCAAyAggAMgIIADICCAAyAggAMgIIADICCAAyAggAMgIIADoHCAAQRxCwAzoECAAQQzoGCAAQFhAeOgkIABBDEEYQggI6CAgAEBYQChAeOgkIABANEEYQggI6BAgAEA1Qvo8yWIWcMmDqoTJoA3AAeACAAUqIAYMDkgEBNpgBAKABAaoBB2d3cy13aXq4AQI&sclient=psy-ab'
    btc_page = requests.get(BTC_USD, headers=headers)
    soup4 = BeautifulSoup(btc_page.content, 'html.parser')
    convert_btc = soup4.findAll("span", {"class": "DFlfde", "class": "SwHCTb", "data-precision": 2})
    usd_za_btc = convert_btc[0].text.replace(",", ".")
    otvet_exchange_rates = otvet_exchange_rates + "1 BTC = " + str(usd_za_btc) + " USD" + "\n"

    return otvet_exchange_rates


def skolko_stoyat_valuti(rub_za_usd, rub_za_euro, rub_za_uah):
    main_yandex_url = 'https://yandex.ru'
    r = requests.get(main_yandex_url)
    soup = BeautifulSoup(r.text, 'html.parser')
    rub_za_usd = float(soup.find_all("span", {"class": "inline-stocks__value_inner"})[0].text.replace(",", "."))
    rub_za_euro = float(soup.find_all("span", {"class": "inline-stocks__value_inner"})[1].text.replace(",", "."))
    UAH_RUB = "https://yandex.ru/news/quotes/10006.html"
    uah_page = requests.get(UAH_RUB, headers=headers)
    soup = BeautifulSoup(uah_page.content, 'html.parser')
    convert_uah = soup.findAll("td", {"class": "quote__value"})
    rub_za_uah = convert_uah[0].text.replace(",", "")
    rub_za_uah = rub_za_uah[:len(rub_za_uah) - 3]
    rub_za_uah = rub_za_uah[0] + "." + rub_za_uah[1:]
    rub_za_uah = float(rub_za_uah)
    return [rub_za_usd, rub_za_euro, rub_za_uah]


def currency_exchange(go_exchange):
    if go_exchange == 1:
        zapros = response
        exchanging = True
        while exchanging:
            try:
                if zapros == "й":
                    go_exchange = 0
                    break
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Загрузка...",
                                                    'random_id': 0})

                words = zapros.split()
                valuta = words[1]
                amount = float(words[0].replace(" ", ""))

                stroka_exchange = ""
                rub_za_usd, rub_za_euro, rub_za_uah = [0, 0, 0]
                if valuta == "rub":
                    rub_za_usd, rub_za_euro, rub_za_uah = skolko_stoyat_valuti(rub_za_usd, rub_za_euro, rub_za_uah)
                    stroka_exchange = "Вы получите: \n" + str(round(amount / rub_za_usd, 2)) + " USD" + "\n" + str(
                        round(amount / rub_za_euro, 2)) + " EURO" + "\n" + str(round(amount / rub_za_uah, 2)) + " UAH"
                elif valuta == "euro":
                    rub_za_usd, rub_za_euro, rub_za_uah = skolko_stoyat_valuti(rub_za_usd, rub_za_euro, rub_za_uah)
                    stroka_exchange = "Вы получите: \n" + str(round(amount * rub_za_euro, 2)) + " RUB" + "\n" + str(
                        round(amount * rub_za_euro / rub_za_usd, 2)) + " USD" + "\n" + str(
                        round(amount * rub_za_euro / rub_za_uah, 2)) + " UAH"
                elif valuta == "usd":
                    rub_za_usd, rub_za_euro, rub_za_uah = skolko_stoyat_valuti(rub_za_usd, rub_za_euro, rub_za_uah)
                    stroka_exchange = "Вы получите: \n" + str(round(amount * rub_za_usd, 2)) + " RUB" + "\n" + str(
                        round(amount * rub_za_usd / rub_za_euro, 2)) + " EURO" + "\n" + str(
                        round(amount * rub_za_usd / rub_za_uah, 2)) + " UAH"
                elif valuta == "uah":
                    rub_za_usd, rub_za_euro, rub_za_uah = skolko_stoyat_valuti(rub_za_usd, rub_za_euro, rub_za_uah)
                    stroka_exchange = "Вы получите: \n" + str(round(amount * rub_za_uah, 2)) + " RUB" + "\n" + str(
                        round(amount * rub_za_uah / rub_za_usd, 2)) + " USD" + "\n" + str(
                        round(amount * rub_za_uah / rub_za_euro, 2)) + " EURO"
                else:
                    print(1 / 0)
                vk_session.method('messages.send',
                                  {'user_id': event.user_id, 'message': stroka_exchange, 'random_id': 0, 'keyboard': keyboard_to_menu})
                go_exchange = 0
                exchanging = False
            except:
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Не могу обработать запрос. Попробуй ввести ещё раз",
                                                    'random_id': 0, 'keyboard': keyboard_to_menu})
                exchanging = False
    else:
        go_exchange = 1
        vk_session.method('messages.send',
                          {'user_id': event.user_id,
                           'message': 'Введи валюту которую хочешь первести и ее количество: RUB, USD, EURO, UAH в формате: "123 usd"',
                           'random_id': 0, 'keyboard': keyboard_to_menu})
    return go_exchange


# Погода
def detect_wind(wind_speed):
    return {
        wind_speed <= 0.2: 'штиль',
        0.2 < wind_speed <= 3.3: 'легкий',
        3.3 < wind_speed <= 5.4: 'слабый',
        5.4 < wind_speed <= 7.9: 'умеренный',
        7.9 < wind_speed <= 10.7: 'свежий',
        10.7 < wind_speed <= 13.8: 'сильный',
        13.8 < wind_speed <= 17.1: 'крепкий',
        17.1 < wind_speed <= 20: 'очень крепкий',
        20 < wind_speed <= 24.4: 'шторм',
        24.4 < wind_speed < 28.4: 'сильный шторм',
        28.4 < wind_speed <= 32.6: 'жестокий шторм',
        32.6 < wind_speed: 'ураган'
    }[True]


def clothes(temperature, wind_speed):
    current_temp = temperature - 0.8 * wind_speed
    return {
        wind_speed > 14: "На улице сильный ветер, из дома лучше не выходить",
        35 < current_temp: "На улице слишком жарко, из дома лучше не выходить",
        22 < current_temp <= 35: "На улице жарко. Надевай футболку и шорты",
        18 < current_temp <= 22: "На улице тепло. Надевай футболку и штаны",
        12 < current_temp <= 18: "На улице свежо. Надевай ветровку",
        4 < current_temp <= 12: "На улице прохладно. Надевай куртку",
        -10 < current_temp <= 4: "На улице холодно. Надевай пуховик",
        -25 < current_temp <= -10: "На улице морозы. Надевай теплый пуховик",
        current_temp <= -25: "На улице слишком холодно, из дома лучше не выходить"
    }[True]


def weather_take(pogod):
    if pogod == 1:
        city = response
        pogoda = True
        while pogoda:
            try:
                if city == "й":
                    pogod = 0
                    break
                # html погода
                continue_with_descript = 1
                descript = " "
                site_url = "https://sinoptik.ua/погода-" + city
                try:
                    r = requests.get(site_url)
                    html = BeautifulSoup(r.content, 'html.parser')
                    for el in html.select('#content'):
                        descript = el.select('.wDescription .description')[0].text
                except:
                    continue_with_descript = 0
                # OWM погода
                owm = pyowm.OWM('6d00d1d4e704068d70191bad2673e0cc', language ='ru')
                observation = owm.weather_at_place(city)
                w_weather = observation.get_weather()
                temperature = w_weather.get_temperature('celsius')['temp']
                temperature = round(temperature, 1)
                wind_speed = w_weather.get_wind()['speed']
                wind_speed = round(wind_speed, 1)

                # определение названия ветра

                wind_type = detect_wind(wind_speed)

                # прогноз одежды
                clothes(temperature, wind_speed)
                pogoda_clothing = clothes(temperature, wind_speed)

                otvet_pogoda = "В городе " + str(city).title() + " сейчас " + str(
                    temperature) + "℃. Ветер: " + wind_type + " (" + str(wind_speed) + " м/с); " + str(
                    w_weather.get_detailed_status()) + "\n"
                if continue_with_descript == 1:
                    otvet_pogoda = otvet_pogoda + "\n" + "Прогноз:" + descript + "\n" + "\n"
                otvet_pogoda = otvet_pogoda + "Совет: " + pogoda_clothing
                vk_session.method('messages.send', {'user_id': event.user_id, 'message': otvet_pogoda, 'random_id': 0, 'keyboard': keyboard_to_menu})
                pogod = 0
                pogoda = False
            except pyowm.exceptions.api_response_error.NotFoundError:
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': "Такого города не существует, попробуй ещё раз.",
                                                    'random_id': 0, 'keyboard': keyboard_weather})
                pogoda = False
    else:
        pogod = 1
        vk_session.method('messages.send',
                          {'user_id': event.user_id,
                           'message': 'В каком городе ты хочешь узнать погоду?',
                           'random_id': 0, 'keyboard': keyboard_weather})
    return pogod


# Мемы
def set_groups(data, domain, ext):
    print('ext =', ext)
    key = str(str(event.user_id) + 'meme_groups')
    groups = []
    if key in data:
        groups = data[key]
        print('Yes key')
    else:
        print('No key')
    if ext == 'добавить':
        print('и тут был')
        groups.append(domain)
    elif ext == 'удалить':
        try:
            groups.remove(domain)
        except:
            print('Такого нет в списке')
    for i in range(len(groups)):
        print(groups[i])
    data[key] = groups

def take_groups(data, max_data): #в данном варианте не используется
    key = str(str(event.user_id) + 'meme_groups')
    groups = []
    if key in data:
        groups = data[key]
        if len(groups) == 0:
            vk_session.method('messages.send', {'user_id': event.user_id,
                                                'message': 'У тебя нет групп в настройках',
                                                'random_id': 0, 'keyboard': keyboard_to_menu})
    else:
        vk_session.method('messages.send', {'user_id': event.user_id,
                                            'message': 'Ты не вбил группы в настройках',
                                            'random_id': 0, 'keyboard': keyboard_to_menu})
    for i in range(len(groups)):
        try:
            response_memes(max_data, groups[i])
        except:
            print('закрытое сообщество')

def sort_memes_key(memes):
    return(memes['likes']['count'])

def response_memes(max_data, domain):
    memes = take_posts(max_data, domain)
    memes.sort(key=sort_memes_key, reverse =  True)
    for i in range(min(len(memes) // 4 + 1, 25)):
        try:
            vk_session.method("messages.send", {"peer_id": event.user_id,"attachment": "wall" + str(memes[i]['from_id']) + "_" + str(memes[i]['id']),'random_id': 0})
        except:
            print('ОШИБКА')
            continue

def take_posts(amount, domain):
    meme_token = 'fbf341ca3d1cb1c81e466abb029f3d4f72b5c76c6764603ec83bd998785a4d77792c3951c0c7525984f4a'
    version = 5.109
    offset = 0
    count = 100
    all_memes = []
    all_posts = []
    print('ЗАШЕВ')
    while True:
        response_memes = requests.get('https://api.vk.com/method/wall.get',
                                      params={
                                          'access_token': meme_token,
                                          'v': version,
                                          'domain': domain,
                                          'count': count,
                                          'offset': offset
                                      })
        get_memes = response_memes.json()['response']['items']
        all_posts.extend(get_memes)
        if (time.time() - all_posts[offset + count - 1]['date']) > (int(amount) * 86000):
            #print("БРЕЙКАЮ")
            break
        else:
            offset += 100
        time.sleep(0.3)
    for i in range(offset + count):
        try:
            if all_posts[i]['is_pinned'] == 1:
                print('pinned')
        except:
            if (time.time() - all_posts[i]['date']) <= int(amount) * 86000:
                vsp = all_posts[i]
                all_memes.append(vsp)
            if (time.time() - all_posts[i]['date']) > (int(amount) * 86000):
                #print("БРЕЙКАЮ")
                break
        #print('я в цикле')
    return(all_memes)

print("Бот запущен")

data = shelve.open('database')
group_data = shelve.open('group_database')

for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW:

        response = event.text.lower()
        if event.from_user and not event.from_me:
            print('Сообщение пришло в: ' + str(datetime.strftime(datetime.now(), "%H:%M:%S")) + ' От ' + str(event.user_id))
            print('Текст сообщения: ' + str(event.text))
            try:
                data[str(event.user_id)] = data[str(event.user_id)]
            except:
                data[str(event.user_id)] = 'menu'
            # Самое начало
            if response == "начать":
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': 'МЕМ БОТ ВКЛЮЧЕН. Чтобы зайти в меню, напиши  - "Меню",',
                                                    'random_id': 0, 'keyboard': keyboard_to_menu})

            # Меню
            elif response == "меню⚙":

                data[str(event.user_id)] = 'menu'


                st= 'Чтобы получить мемы, нажми на кнопку "Мемы😁". \r\n \r\n ' \
                    'Чтобы получить видео, нажми на кнопку "Видео🎬". \r\n \r\n ' \
                    'Чтобы получить музыку, нажми на кнопку "Музыка🎶". \r\n \r\n ' \
                    'Чтобы подкинуть монетку, нажми на кнопку "Монета👌". \r\n \r\n ' \
                    'Чтобы сыграть в камень, ножницы, бумагу, нажми на кнопку "КНБ🖐". \r\n \r\n ' \
                    'Чтобы узнать погоду, нажми на кнопку "Погода⛅".\r\n \r\n ' \
                    'Чтобы узнать текущий курс основных валют, нажми на кнопку "Курс💹".\r\n \r\n ' \
                    'Чтобы перевести свою валюту в другие, нажми на кнопку "Обмен💱". \r\n \r\n ' \
                    'Чтобы воспользоваться переводчиком (ENG-RUS; RUS-ENG), нажми на кнопку "Перевод🤬". \r\n \r\n ' \
                    'Чтобы узнать недавнии новости, нажми на кнопку "Новости📰". \r\n \r\n ' \
                    'Чтобы узнать информацию про владельца страницы, нажми на кнопку "Инфа🔍". \r\n \r\n ' \
                    'Чтобы изменить настройки мемов, нажми на кнопку "Настройки🔧"'

                vk_session.method('messages.send', {'user_id': event.user_id, 'message': st, 'random_id': 0, 'keyboard': keyboard_menu})

            # Мемы
            elif response == "мемы😁":
                data[str(event.user_id)] = 'mem'
                vk_session.method('messages.send', {'user_id': event.user_id,'message': 'Кинь время(в днях)','random_id': 0, 'keyboard': keyboard_to_menu})

            elif data[str(event.user_id)] == 'mem':
                data[str(event.user_id)] = 'menu'
                mem_dom = response[response.rfind('/') + 1:len(response)]
                take_groups(group_data, response)

            # Видео
            elif (response == "видео🎬") or (response == "+" and data[str(event.user_id)] == 'vid'):
                x = random.randint(500, 606)
                data[str(event.user_id)] = 'vid'
                stroka = "video-134895321_456251" + str(x)
                vk_session.method("messages.send", {"peer_id": event.user_id,
                                                    "message": "Держи, если хочешь еще, жми '+'.",
                                                    "attachment": stroka, 'random_id': 0, 'keyboard': keyboard_to_menu_more})

            # Музыка
            elif (response == "музыка🎶") or (response == "+" and data[str(event.user_id)] == 'mus'):
                k = random.randint(600, 924)
                data[str(event.user_id)] = 'mus'
                stroka = "audio-192611626_456241" + str(k)
                vk_session.method("messages.send", {"peer_id": event.user_id,
                                                    "message": "Держи, если хочешь еще, жми '+'.",
                                                    "attachment": stroka + "photo-27895931_457419537", 'random_id': 0, 'keyboard': keyboard_to_menu_more})
                vk_session.method("messages.send",
                                  {"peer_id": event.user_id, "attachment": "photo-27895931_457419537", 'random_id': 0})

            # Настройки интересов Мемов
            elif response == 'чек':
                for i in group_data.values():
                    check_groups = i
                for i in range(len(check_groups)):
                    print(check_groups[i])
                # key = str(str(event.user_id) + 'meme_groups')
                # groups = group_data[key]
                # for i in range(len(groups)):
                #     print(groups[i])
                print('я тут был')
            elif response == "настройки🔧":
                data[str(event.user_id)] = 'settings'
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': 'Ты хочешь удалить или добавить группу?',
                                                    'random_id': 0, 'keyboard': keyboard_settings})
            elif data[str(event.user_id)] == 'settings':
                data[str(event.user_id) + 'set1'] = response
                data[str(event.user_id)] = 'settings2'
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': 'Кинь ссылку на группу',
                                                    'random_id': 0, 'keyboard': keyboard_to_menu})


            elif data[str(event.user_id)] == 'settings2':
                pub_domain = response[response.rfind('/') + 1:len(response)]
                set_groups(group_data, pub_domain, data[str(event.user_id) + 'set1'])
                data[str(event.user_id)] = 'menu'
                print(data[str(event.user_id) + 'set1'])


            # Подкидывание монеты
            elif (response == "монета👌") or (response == "+" and data[str(event.user_id)] == 'coin'):
                a = random.randint(0, 3)
                data[str(event.user_id)] = 'coin'
                if a == 1:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message': (
                        "Орел \r\n Если хочешь еще, жми '+'."),
                                                        'random_id': 0, 'keyboard': keyboard_to_menu_more})
                    vk_session.method("messages.send", {"peer_id": event.user_id,
                                                        "attachment": "photo-196399059_457239322%2Fwall-196399059_3",
                                                        'random_id': 0})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id, 'message': (
                        "Решка \r\n Если хочешь еще, жми '+'."),
                                                        'random_id': 0, 'keyboard': keyboard_to_menu_more})
                    vk_session.method("messages.send", {"peer_id": event.user_id,
                                                        "attachment": "photo-196399059_457239323%2Fwall-196399059_3",
                                                        'random_id': 0})

            # Камень Ножницы Бумага
            elif response == "кнб🖐":
                data[str(event.user_id)] = 'game'
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': 'Напиши мне "К"(Камень), "Н"(Ножницы) или "Б"(Бумага)\r\n Чтобы вернутся в меню, напиши  - "Меню".',
                                                    'random_id': 0, 'keyboard': keyboard_game})

            # Игра
            elif (response == "к" or response == "н" or response == "б") and (data[str(event.user_id)] == 'game'):
                a = random.randint(0, 4)
                if a == 1:
                    st = "к"
                    vk_session.method('messages.send',
                                      {'user_id': event.user_id, 'message': 'Камень✊🏻', 'random_id': 0})
                elif a == 2:
                    st = "н"
                    vk_session.method('messages.send',
                                      {'user_id': event.user_id, 'message': 'Ножницы✌🏻', 'random_id': 0})
                else:
                    st = "б"
                    vk_session.method('messages.send',
                                      {'user_id': event.user_id, 'message': 'Бумага🖐🏻', 'random_id': 0})

                if st == response:
                    vk_session.method('messages.send', {'user_id': event.user_id,
                                                        'message': "Ничья🤡 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага).",
                                                        'random_id': 0, 'keyboard': keyboard_game})
                elif (st == "б" and response == "н") or (st == "н" and response == "к") or (
                        st == "к" and response == "б"):
                    vk_session.method('messages.send', {'user_id': event.user_id,
                                                        'message': "Ты победил👍🏻 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага).",
                                                        'random_id': 0, 'keyboard': keyboard_game})
                else:
                    vk_session.method('messages.send', {'user_id': event.user_id,
                                                        'message': "Ты проиграл😥 \r\n Если хочешь еще, жми 'К'(Камень), 'Н'(Ножницы) или 'Б'(Бумага).",
                                                        'random_id': 0, 'keyboard': keyboard_game})

            # Погода
            elif response == "погода⛅":
                weather_take(0)
                data[str(event.user_id)] = 'wth'
            elif data[str(event.user_id)] == 'wth':
                if weather_take(1) == 0:
                    data[str(event.user_id)] = 'menu'

            # Курс USD, EUR, UAH, BTC
            elif response == "курс💹" or response == "курсы":
                otvet_curs = exchange_rates()
                vk_session.method('messages.send', {'user_id': event.user_id,
                                                    'message': otvet_curs,
                                                    'random_id': 0, 'keyboard': keyboard_to_menu})

            # Переводчик
            elif response == "перевод🤬":
                data[str(event.user_id)] = 'trns'
                translate_to_english(0)
            elif data[str(event.user_id)] == 'trns':
                if translate_to_english(1) == 0:
                    data[str(event.user_id)] = 'menu'

            # Новости
            elif response == "новости📰":
                news(event.user_id)
            elif response.find("н") == 0:
                news_deep(event.user_id, event.text)

            # Информация про владельца странички
            elif response == "инфа🔍":
                data[str(event.user_id)] = 'info'
                vk_session.method('messages.send',
                                  {'user_id': event.user_id, 'message': 'Отправьте ссылку на человека, которого нужно ПрОаНаЛиЗиРоВаТь', 'random_id': 0, 'keyboard': keyboard_to_menu})
            elif data[str(event.user_id)] == 'info':
                info(event.user_id, event.text)
                data[str(event.user_id)] = 'menu'
            elif data[str(event.user_id)] == 'info' and response == "й":
                data[str(event.user_id)] = 'menu'

            # Обмен валюты
            elif response == "обмен💱":
                data[str(event.user_id)] = 'exch'
                currency_exchange(0)
            elif data[str(event.user_id)] == 'exch':
                if currency_exchange(1) == 0:
                    data[str(event.user_id)] = 'menu'
            else:
                vk_session.method('messages.send',
                                  {'user_id': event.user_id, 'message': 'У меня нет такой команды.', 'random_id': 0, 'keyboard': keyboard_menu})
