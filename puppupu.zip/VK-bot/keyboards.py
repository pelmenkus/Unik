import json


def button(label, color):
    return {
        "action": {
            "type": "text",
            "label": label
        },
        "color": color
    }


keyboard_to_menu_struct = {
    "one_time": False,
    "buttons": [
        [button('Меню⚙', "secondary")]
    ]
}

keyboard_to_menu = json.dumps(keyboard_to_menu_struct, ensure_ascii=False).encode('utf-8')

keyboard_to_menu_more_struct = {
    "one_time": False,
    "buttons": [
        [button('+', "secondary")],
        [button('Меню⚙', "secondary")]
    ]
}
keyboard_to_menu_more = json.dumps(keyboard_to_menu_more_struct, ensure_ascii=False).encode('utf-8')

keyboard_menu_struct = {
    "one_time": False,
    "buttons": [
        [button('Мемы😁', "secondary"), button('Видео🎬', "secondary"), button('Музыка🎶', "secondary")],
        [button('Монета👌', "primary"), button('КНБ🖐', "primary"), button('Погода⛅', "primary")],
        [button('Курс💹', "secondary"), button('Обмен💱', "secondary"), button('Перевод🤬', "secondary")],
        [button('Новости📰', "primary"), button('Инфа🔍', "primary"), button('Настройки🔧', "primary")],
    ]
}
keyboard_menu = json.dumps(keyboard_menu_struct, ensure_ascii=False).encode('utf-8')

keyboard_game_struct = {
    "one_time": False,
    "buttons": [
        [button('К', "secondary"), button('Н', "secondary"), button('Б', "secondary")],
        [button('Меню⚙', "secondary")]
    ]
}
keyboard_game = json.dumps(keyboard_game_struct, ensure_ascii=False).encode('utf-8')

keyboard_weather_struct = {
    "one_time": False,
    "buttons": [
        [button('Москва', "secondary"), button('Санкт-Петербург', "secondary"), button('Токио', "secondary")],
        [button('Меню⚙', "secondary")]
    ]
}
keyboard_weather = json.dumps(keyboard_weather_struct, ensure_ascii=False).encode('utf-8')

keyboard_settings_struct = {
    "one_time": False,
    "buttons": [
        [button('Добавить', "positive"), button('Удалить', "negative")],
        [button('Меню⚙', "secondary")]
    ]
}
keyboard_settings = json.dumps(keyboard_settings_struct, ensure_ascii=False).encode('utf-8')

keyboard_meme_struct = {
    "one_time": False,
    "buttons": [
        [button('1', "secondary"), button('2', "secondary"), button('3', "secondary")],
        [button('Меню⚙', "secondary")]
    ]
}
keyboard_meme = json.dumps(keyboard_meme_struct, ensure_ascii=False).encode('utf-8')
