# Инфа

def info(user_id, message):  # шобы работало нужно import bs4 и requests
    try:
        id = message[message.rfind('/') + 1:len(message)]  # оставляю только id пользователя или его "ник"
        parsed_response = vk_session.method('users.get',
                                            {'user_ids': id, 'fields': 'sex, counters'})  # получаю инфу о человеке
        id = str(parsed_response[0]['id'])  # теперь это именно id


        first_name = parsed_response[0]['first_name']  # выкапываю имя
        last_name = parsed_response[0]['last_name']  # вытаскиваю фамилию

        sex_int = parsed_response[0]['sex']  # выкорчовываю пол (0, 1, 2)
        sex = {  # это словарь
            0: 'Не указано ❓',  # очень
            1: 'Дама ♀',  # удобная
            2: 'Джентльмен ♂'  # штука
        }
        sex_str = sex[sex_int]  # получаю человеческое название пола

        write_msg(user_id, ("Имя при крещении: " + first_name + " " + last_name))
        write_msg(user_id, ("Пол: " + sex_str))

        r = requests.get(("https://vk.com/foaf.php?id=" + id))  # парсинг?
        soup = BeautifulSoup(r.text, "html.parser")  # получаем инфу
        created_time = soup.find("ya:created")  # ищем дату создания страницы
        created_time = str(created_time)[21:46]  # обрезаем всё лишнее
        date = {
            '01': 'Января',
            '02': 'Февраля',
            '03': 'Марта',
            '04': 'Апреля',
            '05': 'Мая',
            '06': 'Июня',
            '07': 'Июля',
            '08': 'Августа',
            '09': 'Сентября',
            '10': 'Октября',
            '11': 'Ноября',
            '12': 'Декабря'
        }

        created_time = created_time[0:4] + " год " + str(int(created_time[8:10])) + " " + date[created_time[5:7]] + " " + created_time[11:16] + " по МСК"
        write_msg(user_id, ("⏳Дата создания страницы:\n " + created_time))  # Профит!

        friends = parsed_response[0]['counters']['friends']

        write_msg(user_id, ("Товарищи пользователя: " + str(friends)))  # Профит!

        write_msg(user_id, ("Id при создании: id" + id))
    except:
        write_msg(user_id, "⚠Что-то пошло не так...⚠")

